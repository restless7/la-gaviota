import { clerkMiddleware, createRouteMatcher } from '@clerk/nextjs/server';
import { NextResponse } from 'next/server';
import { getActor, hasCapability } from '@/src/lib/server/authorization';

const isPublicRoute = createRouteMatcher([
  '/',
  '/shop(.*)',
  '/sobre-nosotros(.*)',
  '/product/(.*)',
  '/categoria/(.*)',
  '/comunidad(.*)',
  '/contacto(.*)',
  '/noticias(.*)',
  '/aplicar-negocio(.*)',
  '/sign-in(.*)',
  '/sign-up(.*)',
  '/api/(.*)',
]);

const isAdminRoute = createRouteMatcher(['/admin(.*)']);
const isRestauranteRoute = createRouteMatcher(['/restaurante(.*)']);
const isMicromercadoRoute = createRouteMatcher(['/micromercado(.*)']);

export default clerkMiddleware(async (auth, request) => {
  const url = request.nextUrl;

  // Public routes — no auth required
  if (isPublicRoute(request)) {
    return NextResponse.next();
  }

  // All other routes require authentication
  await auth.protect();

  // Admin routes — require admin role in metadata
  if (isAdminRoute(request)) {
    const actor = await getActor();
    const isAdmin = hasCapability(actor, 'catalog.manage');
    
    if (!isAdmin) {
      // Non-admins get redirected to their dashboard
      return NextResponse.redirect(new URL('/dashboard', request.url));
    }
  }

  // Restaurante routes — require Restaurantes role
  if (isRestauranteRoute(request)) {
    const actor = await getActor();
    const tier = actor.tier;
    const isAdmin = hasCapability(actor, 'catalog.manage');
    
    if (tier !== 'Restaurantes' && !isAdmin) {
      return NextResponse.redirect(new URL('/?error=access_denied_b2b', request.url));
    }
  }

  // Micromercado routes — require Micromercados role
  if (isMicromercadoRoute(request)) {
    const actor = await getActor();
    const tier = actor.tier;
    const isAdmin = hasCapability(actor, 'catalog.manage');
    
    if (tier !== 'Micromercados' && !isAdmin) {
      return NextResponse.redirect(new URL('/?error=access_denied_b2b', request.url));
    }
  }

  // /dashboard — redirect to the correct portal based on role
  if (url.pathname === '/dashboard') {
    const actor = await getActor();
    const tier = actor.tier;
    const isAdmin = hasCapability(actor, 'catalog.manage');

    let targetPath = '/retail';
    if (tier === 'Micromercados') targetPath = '/micromercado';
    if (tier === 'Restaurantes') targetPath = '/restaurante';
    if (isAdmin) targetPath = '/admin';

    return NextResponse.redirect(new URL(targetPath, request.url));
  }

  return NextResponse.next();
});

export const config = {
  matcher: [
    // Skip Next.js internals and static files
    '/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)',
    // Always run for API routes
    '/(api|trpc)(.*)',
  ],
};
