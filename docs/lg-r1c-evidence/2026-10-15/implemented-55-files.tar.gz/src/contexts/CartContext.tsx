'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, fetchProducts } from '@/src/actions/products';
import { parseCartDraft, reconcileCartDraft } from '@/src/lib/cartPersistence';
import { useUserRole } from './UserRoleContext';

export interface CartItem {
  product: Product;
  quantity: number;
  addedAt: number;
}

interface CartContextType {
  items: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (isOpen: boolean) => void;
  cartRestoreError: string | null;
  cartTotal: number;
  itemCount: number;
  freeShippingThreshold: number;
  remainingForFreeShipping: number;
  progressPercent: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);
  const [cartRestoreError, setCartRestoreError] = useState<string | null>(null);
  const { role } = useUserRole();

  useEffect(() => {
    let cancelled = false;
    async function restore() {
      await Promise.resolve();
      if (cancelled) return;
      setIsInitialized(false);
      try {
        const saved = localStorage.getItem('gaviota_cart');
        if (!saved) { if (!cancelled) { setCartRestoreError(null); setIsInitialized(true); } return; }
        const draft = parseCartDraft(saved);
        // Strip legacy costs/prices before fetching; never overwrite this draft on failure.
        localStorage.setItem('gaviota_cart', JSON.stringify(draft));
        const catalog = await fetchProducts();
        if (cancelled) return;
        const restored = reconcileCartDraft(draft, catalog, Date.now());
        setItems(restored.items);
        if (restored.rejected.length) { setCartRestoreError('Hay productos que requieren revisión. Tu selección se conserva; actualiza para reintentar.'); return; }
        setCartRestoreError(null);
        setIsInitialized(true);
      } catch {
        if (!cancelled) setCartRestoreError('No pudimos verificar tu carrito. Tu selección se conserva; actualiza para reintentar.');
      }
    }
    void restore();
    return () => { cancelled = true; };
  }, [role]);

  useEffect(() => {
    if (isInitialized) {
      localStorage.setItem('gaviota_cart', JSON.stringify({ version: 2, items: items.map(item => ({ id: item.product.id, quantity: item.quantity })) }));
      
      // Sync with Abandoned Cart Backend
      const cartTotal = items.reduce((total, item) => {
        const activePrice = role === 'Restaurantes' 
          ? item.product.price 
          : role === 'Micromercados' 
            ? item.product.price 
            : item.product.price;
        return total + (activePrice * item.quantity);
      }, 0);

      fetch('/api/marketing/abandoned-cart/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items,
          cartTotal,
          isCompleted: false
        })
      }).catch(err => console.warn('Failed to sync cart', err));
    }
  }, [items, isInitialized, role]);

  const addToCart = (product: Product, quantity = 1) => {
    if (!isInitialized || cartRestoreError) return;
    setItems(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.product.id === product.id 
            ? { ...item, quantity: item.quantity + quantity } 
            : item
        );
      }
      return [...prev, { product, quantity, addedAt: Date.now() }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string) => {
    setItems(prev => prev.filter(item => item.product.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (!isInitialized || cartRestoreError) return;
    if (quantity < 1) return;
    setItems(prev => prev.map(item => 
      item.product.id === productId ? { ...item, quantity } : item
    ));
  };

  const clearCart = () => setItems([]);

  // Calculate totals relying on UserRole dynamic pricing
  const cartTotal = items.reduce((total, item) => {
    const activePrice = role === 'Restaurantes' 
      ? item.product.price 
      : role === 'Micromercados' 
        ? item.product.price 
        : item.product.price;
    return total + (activePrice * item.quantity);
  }, 0);

  const itemCount = items.reduce((total, item) => total + item.quantity, 0);

  // Phase 5: Free shipping metrics
  const freeShippingThreshold = 50000;
  const remainingForFreeShipping = Math.max(0, freeShippingThreshold - cartTotal);
  const progressPercent = Math.min(100, (cartTotal / freeShippingThreshold) * 100);

  return (
    <CartContext.Provider value={{
      items, addToCart, removeFromCart, updateQuantity, clearCart,
      isCartOpen, setIsCartOpen, cartRestoreError, cartTotal, itemCount,
      freeShippingThreshold, remainingForFreeShipping, progressPercent
    }}>
      {cartRestoreError && <div role="alert" className="p-4 bg-amber-50 text-amber-900">{cartRestoreError}</div>}
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used within a CartProvider');
  return context;
}
