'use server';
import { requireCapability, requireOwnedSubject, validateTier, assertTargetId } from '@/src/lib/server/authorization';
import { getServerDatabase } from '@/src/lib/server/database';



import { clerkClient } from '@clerk/nextjs/server';
import type { BusinessTier } from '@/src/lib/supabase';

// ---------- Submit Business Application ----------
export async function submitBusinessApplication(formData: {
  clerkUserId: string;
  applicantName: string;
  applicantEmail: string;
  businessName: string;
  businessType: BusinessTier;
  nit: string;
  phone: string;
  address: string;
  municipality: string;
  monthlyVolume: string;
  notes: string;
}) {
  const actor = await requireOwnedSubject(formData.clerkUserId);
  const supabase = getServerDatabase(actor);
  validateTier(formData.businessType);

  try {
    const { data, error } = await supabase
      .from('business_applications')
      .insert({
        clerk_user_id: formData.clerkUserId,
        applicant_name: formData.applicantName,
        applicant_email: formData.applicantEmail,
        business_name: formData.businessName,
        business_type: formData.businessType,
        nit: formData.nit,
        phone: formData.phone,
        address: formData.address,
        municipality: formData.municipality,
        monthly_volume: formData.monthlyVolume,
        notes: formData.notes,
        status: 'pending',
      })
      .select()
      .single();

    if (error) {
      console.error('Supabase insert error:', error);
      return { success: false, error: error.message };
    }

    return { success: true, data };
  } catch (err) {
    console.error('Submit application error:', err);
    return { success: false, error: 'Error inesperado al enviar la solicitud.' };
  }
}

// ---------- Fetch All Applications (Admin) ----------
export async function fetchBusinessApplications() {
  const actor = await requireCapability('customers.manage');
  const supabase = getServerDatabase(actor);

  try {
    const { data, error } = await supabase
      .from('business_applications')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Fetch applications error:', error);
      return { success: false, error: error.message, data: [] };
    }

    return { success: true, data: data || [] };
  } catch (err) {
    console.error('Fetch error:', err);
    return { success: false, error: 'Error al cargar solicitudes.', data: [] };
  }
}

// ---------- Approve Application (Admin) ----------
export async function approveApplication(applicationId: string, clerkUserId: string, businessType: BusinessTier, businessName: string, adminName: string) {
  const actor = await requireCapability('tiers.manage');
  const supabase = getServerDatabase(actor);

  void adminName; // Attribution comes from the issued actor, never the caller name.
  assertTargetId(applicationId);
  assertTargetId(clerkUserId);
  validateTier(businessType);
  try {
    // 1. Update Clerk user metadata to grant the tier
    const client = await clerkClient();
    await client.users.updateUserMetadata(clerkUserId, {
      publicMetadata: {
        tier: businessType,
        businessName: businessName,
        approvedAt: new Date().toISOString(),
      },
    });

    // 2. Update application status in Supabase
    const { error } = await supabase
      .from('business_applications')
      .update({
        status: 'approved',
        reviewed_by: actor.userId,
        reviewed_at: new Date().toISOString(),
      })
      .eq('id', applicationId);

    if (error) {
      console.error('Supabase update error:', error);
      return { success: false, error: error.message };
    }

    // 3. Create/Update customer record in 'customers' table
    // Fetch the application details to get all info
    const { data: appData } = await supabase
      .from('business_applications')
      .select('*')
      .eq('id', applicationId)
      .single();

    if (appData) {
      await supabase
        .from('customers')
        .upsert({
          clerk_user_id: clerkUserId,
          full_name: appData.applicant_name,
          business_name: appData.business_name,
          email: appData.applicant_email,
          phone: appData.phone,
          address: appData.address,
          nit: appData.nit,
          tier: businessType,
          updated_at: new Date().toISOString()
        });
    }

    return { success: true };
  } catch (err) {
    console.error('Approve error:', err);
    return { success: false, error: 'Error al aprobar la solicitud.' };
  }
}

// ---------- Reject Application (Admin) ----------
export async function rejectApplication(applicationId: string, adminName: string) {
  const actor = await requireCapability('tiers.manage');
  const supabase = getServerDatabase(actor);

  void adminName; // Attribution comes from the issued actor, never the caller name.
  assertTargetId(applicationId);
  try {
    const { error } = await supabase
      .from('business_applications')
      .update({
        status: 'rejected',
        reviewed_by: actor.userId,
        reviewed_at: new Date().toISOString(),
      })
      .eq('id', applicationId);

    if (error) {
      console.error('Supabase update error:', error);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (err) {
    console.error('Reject error:', err);
    return { success: false, error: 'Error al rechazar la solicitud.' };
  }
}
